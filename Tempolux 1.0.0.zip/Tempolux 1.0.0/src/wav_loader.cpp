#include <fstream>
#include <cstring>
#include "../include/tempolux.h"

// Define the basic audio channel tracking memory layout matching core mixer expectations
struct AudioChannelInternal {
    short* pSamples = nullptr;
    unsigned int sampleCount = 0;
    unsigned int currentPos = 0;
    float volume = 1.0f;
    float panning = 0.0f; 
    bool isLooping = false;
    bool isActive = false;
    bool isPaused = false;
};

// Safe type-cast wrapper processing file streams
bool load_wav_internal(const std::string& filepath, void* channelPtr) {
    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) return false;

    AudioChannelInternal* channel = static_cast<AudioChannelInternal*>(channelPtr);
    char chunkId[4];
    file.seekg(12); // Skip primary RIFF tracking IDs

    while (file.read(chunkId, 4)) {
        unsigned int chunkSize = 0;
        file.read(reinterpret_cast<char*>(&chunkSize), 4);

        if (std::memcmp(chunkId, "data", 4) == 0) {
            channel->sampleCount = chunkSize / 2;
            channel->pSamples = new short[channel->sampleCount];
            file.read(reinterpret_cast<char*>(channel->pSamples), chunkSize);
            channel->currentPos = 0;
            channel->isActive = true;
            channel->isPaused = false;
            return true;
        } else {
            file.seekg(chunkSize, std::ios::cur);
        }
    }
    return false;
}
