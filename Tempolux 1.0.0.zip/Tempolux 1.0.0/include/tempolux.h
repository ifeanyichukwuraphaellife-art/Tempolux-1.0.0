#ifndef TEMPOLUX_H
#define TEMPOLUX_H

#include <string>

#ifdef BUILD_DLL
    #define TEMPOLUX_API __declspec(dllexport)
#else
    #define TEMPOLUX_API __declspec(dllimport)
#endif

// Modern Industry-Standard Object-Oriented C++ Interface Wrapper
class TEMPOLUX_API TempoluxEngine {
public:
    // Constructor handles automated hardware subsystem activation
    TempoluxEngine() {
        init();
    }

    // Destructor guarantees memory-safe hardware release when object drops out of scope
    ~TempoluxEngine() {
        shutdown();
    }

    // Public class object tracking method signatures
    bool init();
    void playMusic(const std::string& filepath);
    void stopMusic();
    void playSound(const std::string& filepath);
    void setMusicVolume(float volume);
    void setSoundVolume(float volume);
    void setMusicPanning(float panning);
    void setSoundPanning(float panning);
    void pauseMusic();
    void resumeMusic();
    bool isMusicPlaying();
    bool isMusicPaused();
    void shutdown();
};

// Underlying Raw C-Linkage Bindings (Preserved for Cross-Language bindings/Python)
extern "C" {
    TEMPOLUX_API bool tempolux_init();
    TEMPOLUX_API void tempolux_play_music(const char* filepath);
    TEMPOLUX_API void tempolux_stop_music();
    TEMPOLUX_API void tempolux_play_sound(const char* filepath);
    TEMPOLUX_API void tempolux_set_music_volume(float volume);
    TEMPOLUX_API void tempolux_set_sound_volume(float volume);
    TEMPOLUX_API void tempolux_pause_music();
    TEMPOLUX_API void tempolux_resume_music();
    TEMPOLUX_API bool tempolux_is_music_playing();
    TEMPOLUX_API bool tempolux_is_music_paused();
    TEMPOLUX_API void tempolux_set_music_panning(float panning);
    TEMPOLUX_API void tempolux_set_sound_panning(float panning);
    TEMPOLUX_API void tempolux_shutdown();
}

#endif // TEMPOLUX_H
