#include "../include/tempolux.h"
#include <windows.h>
#include <mmsystem.h>
#include <string>
#include <thread>
#include <mutex>
#include <cstring>

const int SAMPLE_RATE = 44100;
const int BUFFER_SAMPLES = 4096; 
const int MAX_CHANNELS = 16;

struct AudioChannel {
    short* pSamples = nullptr;
    unsigned int sampleCount = 0;
    unsigned int currentPos = 0;
    float volume = 1.0f;
    float panning = 0.0f; 
    bool isLooping = false;
    bool isActive = false;
    bool isPaused = false;
};

// External linking prototype signature pointing to the chunk loader file block
extern bool load_wav_internal(const std::string& filepath, void* channelPtr);

// Global State Arrays
HWAVEOUT hWaveOut = NULL;
AudioChannel channels[MAX_CHANNELS];
std::mutex mixerMutex;
bool isRunning = false;
std::thread mixerThread;

// Double buffer structures explicitly split to satisfy indexed loops
WAVEHDR waveHeaders[2];
short audioBuffers[2][BUFFER_SAMPLES * 2];

void audio_mixer_loop() {
    int currentBufferIndex = 0;

    while (isRunning) {
        WAVEHDR* header = &waveHeaders[currentBufferIndex];

        if (header->dwFlags & WHDR_DONE) {
            std::lock_guard<std::mutex> lock(mixerMutex);
            short* output = audioBuffers[currentBufferIndex];

            std::memset(output, 0, BUFFER_SAMPLES * 2 * sizeof(short));

            for (int c = 0; c < MAX_CHANNELS; ++c) {
                if (!channels[c].isActive || channels[c].isPaused || channels[c].pSamples == nullptr) continue;

                for (int i = 0; i < BUFFER_SAMPLES * 2; i += 2) {
                    if (channels[c].currentPos >= channels[c].sampleCount - 1) {
                        if (channels[c].isLooping) {
                            channels[c].currentPos = 0;
                        } else {
                            channels[c].isActive = false;
                            break;
                        }
                    }

                    float rawLeft = static_cast<float>(channels[c].pSamples[channels[c].currentPos]);
                    float rawRight = static_cast<float>(channels[c].pSamples[channels[c].currentPos + 1]);

                    float panLeft = 1.0f;
                    float panRight = 1.0f;
                    
                    if (channels[c].panning < 0.0f) {
                        panRight = 1.0f + channels[c].panning; 
                    } else if (channels[c].panning > 0.0f) {
                        panLeft = 1.0f - channels[c].panning;  
                    }

                    float finalLeft = rawLeft * channels[c].volume * panLeft;
                    float finalRight = rawRight * channels[c].volume * panRight;

                    int mixL = output[i] + static_cast<int>(finalLeft);
                    int mixR = output[i + 1] + static_cast<int>(finalRight);

                    if (mixL > 32767) mixL = 32767; else if (mixL < -32768) mixL = -32768;
                    if (mixR > 32767) mixR = 32767; else if (mixR < -32768) mixR = -32768;

                    output[i] = static_cast<short>(mixL);
                    output[i + 1] = static_cast<short>(mixR);

                    channels[c].currentPos += 2;
                }
            }

            header->dwFlags &= ~WHDR_DONE;
            waveOutPrepareHeader(hWaveOut, header, sizeof(WAVEHDR));
            waveOutWrite(hWaveOut, header, sizeof(WAVEHDR));

            currentBufferIndex = (currentBufferIndex + 1) % 2;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

extern "C" {
    TEMPOLUX_API bool tempolux_init() {
        if (hWaveOut != NULL) return true;

        WAVEFORMATEX wfx = {0};
        wfx.wFormatTag = WAVE_FORMAT_PCM;
        wfx.nChannels = 2;              
        wfx.nSamplesPerSec = SAMPLE_RATE; 
        wfx.wBitsPerSample = 16;        
        wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
        wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

        if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
            return false;
        }

        isRunning = true;

        for (int i = 0; i < 2; ++i) {
            std::memset(audioBuffers[i], 0, BUFFER_SAMPLES * 2 * sizeof(short));
            waveHeaders[i].lpData = reinterpret_cast<LPSTR>(audioBuffers[i]);
            waveHeaders[i].dwBufferLength = BUFFER_SAMPLES * 2 * sizeof(short);
            waveHeaders[i].dwFlags = 0;
            
            waveOutPrepareHeader(hWaveOut, &waveHeaders[i], sizeof(WAVEHDR));
            waveOutWrite(hWaveOut, &waveHeaders[i], sizeof(WAVEHDR));
        }

        mixerThread = std::thread(audio_mixer_loop);
        return true;
    }

    TEMPOLUX_API void tempolux_play_music(const char* filepath) {
        std::lock_guard<std::mutex> lock(mixerMutex);
        if (channels[0].pSamples != nullptr) {
            delete[] channels[0].pSamples;
            channels[0].pSamples = nullptr;
        }
        if (load_wav_internal(filepath, &channels[0])) {
            channels[0].isLooping = true;
        }
    }

    TEMPOLUX_API void tempolux_stop_music() {
        std::lock_guard<std::mutex> lock(mixerMutex);
        channels[0].isActive = false;
        channels[0].isPaused = false;
    }

    TEMPOLUX_API void tempolux_play_sound(const char* filepath) {
        std::lock_guard<std::mutex> lock(mixerMutex);
        for (int i = 1; i < MAX_CHANNELS; ++i) {
            if (!channels[i].isActive) {
                if (channels[i].pSamples != nullptr) {
                    delete[] channels[i].pSamples;
                    channels[i].pSamples = nullptr;
                }
                if (load_wav_internal(filepath, &channels[i])) {
                    channels[i].isLooping = false;
                }
                break;
            }
        }
    }

    TEMPOLUX_API void tempolux_set_music_volume(float volume) {
        std::lock_guard<std::mutex> lock(mixerMutex);
        if (volume < 0.0f) volume = 0.0f;
        if (volume > 1.0f) volume = 1.0f;
        channels[0].volume = volume;
    }

    TEMPOLUX_API void tempolux_set_sound_volume(float volume) {
        std::lock_guard<std::mutex> lock(mixerMutex);
        if (volume < 0.0f) volume = 0.0f;
        if (volume > 1.0f) volume = 1.0f;
        for (int i = 1; i < MAX_CHANNELS; ++i) {
            channels[i].volume = volume;
        }
    }

    TEMPOLUX_API void tempolux_pause_music() {
        std::lock_guard<std::mutex> lock(mixerMutex);
        if (channels[0].isActive) {
            channels[0].isPaused = true;
        }
    }

    TEMPOLUX_API void tempolux_resume_music() {
        std::lock_guard<std::mutex> lock(mixerMutex);
        if (channels[0].isActive) {
            channels[0].isPaused = false;
        }
    }

    TEMPOLUX_API bool tempolux_is_music_playing() {
        std::lock_guard<std::mutex> lock(mixerMutex);
        return (channels[0].isActive && !channels[0].isPaused);
    }

    TEMPOLUX_API bool tempolux_is_music_paused() {
        std::lock_guard<std::mutex> lock(mixerMutex);
        return (channels[0].isActive && channels[0].isPaused);
    }

    TEMPOLUX_API void tempolux_set_music_panning(float panning) {
        std::lock_guard<std::mutex> lock(mixerMutex);
        if (panning < -1.0f) panning = -1.0f;
        if (panning > 1.0f) panning = 1.0f;
        channels[0].panning = panning;
    }

    TEMPOLUX_API void tempolux_set_sound_panning(float panning) {
        std::lock_guard<std::mutex> lock(mixerMutex);
        if (panning < -1.0f) panning = -1.0f;
        if (panning > 1.0f) panning = 1.0f;
        for (int i = 1; i < MAX_CHANNELS; ++i) {
            channels[i].panning = panning;
        }
    }

    TEMPOLUX_API void tempolux_shutdown() {
        isRunning = false;
        if (mixerThread.joinable()) mixerThread.join();
        if (hWaveOut) {
            waveOutReset(hWaveOut);
            for (int i = 0; i < 2; ++i) {
                waveOutUnprepareHeader(hWaveOut, &waveHeaders[i], sizeof(WAVEHDR));
            }
            waveOutClose(hWaveOut);
            hWaveOut = NULL;
        }
        for (int i = 0; i < MAX_CHANNELS; ++i) {
            if (channels[i].pSamples != nullptr) {
                delete[] channels[i].pSamples;
                channels[i].pSamples = nullptr;
            }
        }
    }
}

// Class Interface Passthrough definitions
bool TempoluxEngine::init() { return tempolux_init(); }
void TempoluxEngine::playMusic(const std::string& filepath) { tempolux_play_music(filepath.c_str()); }
void TempoluxEngine::stopMusic() { tempolux_stop_music(); }
void TempoluxEngine::playSound(const std::string& filepath) { tempolux_play_sound(filepath.c_str()); }
void TempoluxEngine::setMusicVolume(float volume) { tempolux_set_music_volume(volume); }
void TempoluxEngine::setSoundVolume(float volume) { tempolux_set_sound_volume(volume); }
void TempoluxEngine::setMusicPanning(float panning) { tempolux_set_music_panning(panning); }
void TempoluxEngine::setSoundPanning(float panning) { tempolux_set_sound_panning(panning); }
void TempoluxEngine::pauseMusic() { tempolux_pause_music(); }
void TempoluxEngine::resumeMusic() { tempolux_resume_music(); }
bool TempoluxEngine::isMusicPlaying() { return tempolux_is_music_playing(); }
bool TempoluxEngine::isMusicPaused() { return tempolux_is_music_paused(); }
void TempoluxEngine::shutdown() { tempolux_shutdown(); }
