# Tempolux Audio Engine v1.0.0

A high-performance, low-latency, zero-dependency C++ multi-channel software audio mixing library built natively from scratch for Windows 10. Tempolux streams interleaved stereo channels directly over the low-level Windows Multimedia driver subsystem (`waveOut`), managing independent looping background tracks and concurrent overlapping sound effects seamlessly without secondary file installations.

## 🛠️ Repository File Structure

* `/include/tempolux.h` - Public header definitions exposing raw C linkage bindings.
* `/src/tempolux.cpp` - Core mixer loop implementation with ping-pong double buffering.
* `/bin/` - Deployment location for the compiled runtime module (`tempolux.dll`).
* `/lib/` - Development location for the linkage architecture import blueprint (`libtempolux.a`).

## 🚀 Quick Start Compilation

Ensure your path tracking includes standard MinGW-w64 (`g++`). Run the automated build macro to package the core library and construct the application testing layout:

```cmd
build.bat
```

## 💻 Developer Code Integration Example

Link your game loop or desktop application layout against `-Llib -ltempolux`, include `include/tempolux.h`, and copy `tempolux.dll` to your root executable directory:

```cpp
#include <windows.h>
#include "include/tempolux.h"

int main() {
    // 1. Prime the real-time background mixing hardware thread
    if (!tempolux_init()) return -1;

    // 2. Load and loop the background track at a soft 30% volume mix
    tempolux_play_music("soundtrack.wav");
    tempolux_set_music_volume(0.3f);

    // 3. Fire fire-and-forget concurrent sound layers without clipping distortion
    tempolux_play_sound("laser_blast.wav");
    tempolux_play_sound("explosion.wav"); // Plays over laser simultaneously!

    Sleep(5000); // Keep application context active while threads stream data

    // 4. Tear down audio pipelines safely and release system handles
    tempolux_stop_music();
    tempolux_shutdown();
    return 0;
}
```
